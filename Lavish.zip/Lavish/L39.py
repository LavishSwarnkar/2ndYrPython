str1 = input("Enter a string: ")
list1 = list(str1)
print('*'.join(list1))

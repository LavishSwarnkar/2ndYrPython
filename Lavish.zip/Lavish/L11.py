import calendar
year = int(input('Enter Year: '))
month = int(input('Enter Month: '))
print(calendar.month(year,month))


import re
p1 = r"^['\"]{3}\w*"
p2 = r"\w*['\"]{3}$"
print(bool(re.match(p1,'"""ABC\n')))
print(re.match(p2,'DEF"""'))

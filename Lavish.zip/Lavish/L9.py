x = input("Enter a string: ")
print('Length of enetered string is', len(x))


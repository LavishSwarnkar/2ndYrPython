x = int(input("Enter first number: "))
y = int(input("Enter second number: "))
print(x,'+',y,'=',x+y)
# OR print(str(x) + '+' + str(y) + '=' + str(x+y))

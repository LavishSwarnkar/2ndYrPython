from datetime import date
d1 = date(2019,1,12)
d2 = date(2019,12,19)
print((d2-d1).days,'days')


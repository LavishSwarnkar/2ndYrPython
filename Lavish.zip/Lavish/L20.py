x = int(input("Enter first number: "))
y = int(input("Enter second number: "))
print("Bitwise COMPLEMENT: ~", x, "=", ~x, ", ~", y, "=", ~y)
print("Bitwise AND: ", x, "&", y, "=", x&y)
print("Bitwise OR: ", x, "|", y, "=", x|y)
print("Bitwise XOR: ", x, "^", y, "=", x^y)
print("Bitwise LEFT SHIFT: ", x, "&", y, "=", x<<y)
print("Bitwise RIGHT SHIFT: ", x, "&", y, "=", x>>y)



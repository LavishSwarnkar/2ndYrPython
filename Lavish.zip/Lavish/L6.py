ch = input("Enter a character: ")
if(ch=='a' or ch=='A'
   or ch=='e' or ch=='E'
   or ch=='i' or ch=='I'
   or ch=='o' or ch=='O'
   or ch=='u' or ch=='U'):
    print("It is a vowel.")
else:
    print("It is not a vowel.")


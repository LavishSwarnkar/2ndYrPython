x = int(input("Enter a number: "))
if(x%2==0):
    print("It is a even number.")
else:
    print("It is a odd number.")


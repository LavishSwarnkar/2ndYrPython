#Comment 1
print("Hi")
#Comment 2
"""ABC
DEF"""
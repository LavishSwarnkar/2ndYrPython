print("Hi")

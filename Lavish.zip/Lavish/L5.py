ch = input("Enter a character: ")
if(ch>='a' and ch<='z' or ch>='A' and ch<='Z'):
    print("It is a character.")
else:
    print("It is not a character.")


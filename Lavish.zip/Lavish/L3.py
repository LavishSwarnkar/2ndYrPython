x = int(input("Enter a number: "))
if(x<0):
    print("It is a negative number.")
else:
    print("It is a positive number.")


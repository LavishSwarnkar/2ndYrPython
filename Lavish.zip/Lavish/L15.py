age = int(input("Enter your age: "))
if(age>=18):
    print("Voila! You are eligible to vote.")
else:
    print("Oops! You can vote after", 18-age ,"years only.")


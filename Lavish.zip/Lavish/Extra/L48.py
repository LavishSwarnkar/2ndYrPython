l1 = [1,5,547,76,7,987,7]
print(sorted(l1))

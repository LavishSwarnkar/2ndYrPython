l1 = [544,66,728,29,276,26,4]
print("Before sorting:", l1)
l1.sort()
print("After ascending sorting:", l1)
l1.reverse()
print("After descending sorting:", l1)

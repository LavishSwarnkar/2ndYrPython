l1 = [1,333,454,765,446,543]
print("Smallest no. in ", l1, "is", min(l1))
print("Largest no. in ", l1, "is", max(l1))

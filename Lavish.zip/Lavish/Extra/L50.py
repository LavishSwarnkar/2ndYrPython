l1 = [43753,543,32,2,2,4]
print("Before appending: ", l1)
l1.append(54)
print("After appending 54: ", l1)




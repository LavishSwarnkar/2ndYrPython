l1 = [0,1,2,3]
l2 = [4,5,6,7]
l1.extend(l2)
print(l1, l2)

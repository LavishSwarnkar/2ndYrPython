l1 = ["A", "E", "I", "O", "U"]
if input("Enter a character: ").upper() in l1:
    print("It is a vowel!")
else:
    print("It is a consonant!")

l1 = ["Apple", "Ball", "Cat"]
print("l1[0]: ", l1[0])
print("l1[-1]: ", l1[-1])
print("l1[-3]: ", l1[-3])

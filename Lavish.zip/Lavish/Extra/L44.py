l1 = [1,333,454,765,446,543]
print("Sum of all no. in ", l1, "is", sum(l1))

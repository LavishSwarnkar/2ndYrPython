l1 = [4,6,2,2,2,2,4]
print("2 comes", l1.count(2), "times in", l1)


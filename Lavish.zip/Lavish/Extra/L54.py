l1 = [4,6,2,2,2,2,4]
print("Before pop:", l1)
l1.pop(1)
print("After pop at index 1:", l1)

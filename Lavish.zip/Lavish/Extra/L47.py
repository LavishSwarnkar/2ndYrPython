print(list("Lavish"))

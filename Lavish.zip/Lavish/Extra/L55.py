l1 = [4,6,2,2,2,2,4]
print("Before removing:", l1)
l1.remove(4)
print("After removing first 4:", l1)

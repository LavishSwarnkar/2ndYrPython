l1 = [4,6,2,2,2,2,4]
print("Before inserting:", l1)
l1.insert(0, 10)
print("After inserting 10 at index 0:", l1)


l1 = [0,1,2,3,4,5,6]
print("Before removing:", l1)
del l1[3]
print("After removing value at index 3:", l1)
del l1[1:3]
print("After removing value from index 1 to 3:", l1)
list[1:3] = []
print("After removing value at index 3:", l1)


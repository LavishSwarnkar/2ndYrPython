r = int(input("Enter radius of circle: "))
print('Circumference of circle is', 2*3.14*r)


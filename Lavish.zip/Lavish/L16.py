ch = input("Enter a character: ")
if(ch.isupper()):
    print("Lowercase of", ch, "is", ch.lower())
else:
    print("Uppercase of", ch, "is", ch.upper())


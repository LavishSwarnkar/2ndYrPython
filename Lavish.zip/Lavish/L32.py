str1 = input("Enter a string: ")
print("Length of string", str1, "is", len(str1))

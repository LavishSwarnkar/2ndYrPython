x = int(input("Enter a number: "))
fact = 1
for i in range(x,0,-1):
    fact*=i
print("Factorial of", x, "is",fact)




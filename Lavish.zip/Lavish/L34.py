str1 = "RESTART"
print(str1, " -> ", str1.replace('R', '$'))

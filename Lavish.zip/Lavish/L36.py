str1 = input("Enter a string: ")
list1 = str1.split()
list1.reverse()
print(' '.join(list1))

